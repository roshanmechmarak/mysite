
const noBtn = document.getElementById('noBtn');
const yesBtn = document.getElementById('yesBtn');

function moveNoButton() {
    const maxX = window.innerWidth - noBtn.offsetWidth;
    const maxY = window.innerHeight - noBtn.offsetHeight;
    const x = Math.random() * maxX;
    const y = Math.random() * maxY;
    noBtn.style.left = `${x}px`;
    noBtn.style.top = `${y}px`;
}

noBtn.addEventListener('touchstart', (e) => {
    e.preventDefault();
    moveNoButton();
});

noBtn.addEventListener('mouseover', () => {
    moveNoButton();
});

yesBtn.addEventListener('click', () => {
    alert('Congrats now urr officially gay');
});
